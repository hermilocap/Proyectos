export default [
    {
        input: 'site/index.js',
        output: {
            file: 'site/bundle.js',
            format: 'iife'
        }
    }
];
